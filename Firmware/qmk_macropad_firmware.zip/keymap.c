#include QMK_KEYBOARD_H
#include "rgb_indicator.h"

enum layer_names {
    _LAYER0,
    _LAYER1,
    _LAYER2,
    _LAYER3
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    [_LAYER0] = LAYOUT_ortho_3x3(
        KC_7, KC_4, KC_1,
        KC_8, KC_5, KC_2,
        KC_9, KC_6, KC_3
    ),
    [_LAYER1] = LAYOUT_ortho_3x3(
        _______, _______, _______,
        _______, _______, _______,
        _______, _______, _______
    ),
    [_LAYER2] = LAYOUT_ortho_3x3(
        _______, _______, _______,
        _______, _______, _______,
        _______, _______, _______
    ),
    [_LAYER3] = LAYOUT_ortho_3x3(
        _______, _______, _______,
        _______, _______, _______,
        _______, _______, _______
    )
};

layer_state_t layer_state_set_user(layer_state_t state) {
    update_layer_rgb(get_highest_layer(state));
    return state;
}

bool rgb_matrix_indicators_advanced_user(uint8_t led_min, uint8_t led_max) {
    return false;
}

void keyboard_post_init_user(void) {
    startup_rgb_animation();
}