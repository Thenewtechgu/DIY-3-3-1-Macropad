#pragma once

void update_layer_rgb(uint8_t layer);
void startup_rgb_animation(void);