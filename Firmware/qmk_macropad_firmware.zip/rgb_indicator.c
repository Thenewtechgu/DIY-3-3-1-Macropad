#include "quantum.h"

void update_layer_rgb(uint8_t layer) {
    rgblight_setrgb_range(0, 0, 0, 0, 0, 4);  // turn all off first
    if (layer < 4) {
        switch (layer) {
            case 0:
                rgblight_setrgb_at(0, 0, 255, 0); break;
            case 1:
                rgblight_setrgb_at(0, 0, 0, 255); break;
            case 2:
                rgblight_setrgb_at(255, 0, 0, 2); break;
            case 3:
                rgblight_setrgb_at(255, 255, 0, 3); break;
        }
    }
}

void startup_rgb_animation(void) {
    for (int i = 0; i < 4; i++) {
        rgblight_setrgb_at(255, 0, 0, i);
        wait_ms(100);
        rgblight_setrgb_at(0, 255, 0, i);
        wait_ms(100);
        rgblight_setrgb_at(0, 0, 255, i);
        wait_ms(100);
        rgblight_setrgb_at(0, 0, 0, i);
    }
}